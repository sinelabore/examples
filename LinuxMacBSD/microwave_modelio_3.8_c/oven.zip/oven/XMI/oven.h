/*
 * (c) Peter Mueller, 2008 - 2015
 *
 * All rights reserved. Reproduction, modification,
 * use or disclosure to third parties without express
 * authority is forbidden.
 */

/* Command line options: -p Modelio -t OvenClass -o oven oven.xmi   */
/* This file is generated from oven.xmi - do not edit manually*/
/* Generated on: Tue Sep 15 20:55:47 CEST 2015 / version 3.6.11-b1 */


#ifndef __OVEN_H__
#define __OVEN_H__


/* Header to define simple data types */
#include <stdint.h>

/* State definitions */
typedef enum{
	CookingPause,
	Cooking,
	Completed,
	Super,
	Idle,
	__OVEN_LAST_STATE__} OVEN_STATES_T;






/* Predefined types required by the codegen. You can provide your own  */
/* definitions by setting the following define somewhere in your built env. */
#ifndef __PROVIDE_OWN_OVEN_STATEMACHINE_TYPES__
	typedef uint8_t OVEN_ENTRY_FLAG_T;
	typedef OVEN_STATES_T OVEN_STATEVAR_T;
	typedef uint8_t OVEN_INST_ID_T;
	typedef uint8_t OVEN_EV_CONSUMED_FLAG_T ;
#endif




/* Instance data definition of state machine */
typedef struct{
	OVEN_ENTRY_FLAG_T superEntry;
	OVEN_STATEVAR_T stateVar;
	OVEN_STATEVAR_T stateVarSuper;
	OVEN_INST_ID_T inst_id;
} OVEN_INSTANCEDATA_T;

/* Helper to initialize the machine's instance data */
#define OVEN_INSTANCEDATA_INIT {\
	1,\
	(OVEN_STATEVAR_T) Super /* set init state of top state */,\
	(OVEN_STATEVAR_T) Idle /* set init state of Super */,\
	0 /* instance id */ } 

/* Helper(s) to reset history */
#define OVEN_RESET_HISTORY_SUPER(instance) ((&instance)->stateVarSuper=Idle)
/* Region handler prototypes  */

/*Prototype of the state machine function */
void  oven(OVEN_INSTANCEDATA_T *instanceVar);


/*Prototoye of the reset machine function */
void ovenResetMachine(OVEN_INSTANCEDATA_T *instanceVar);

// Helper(s) to reset history
void ovenResetHistorySuper(OVEN_INSTANCEDATA_T *instanceVar);

// Helper(s) to find out if the machine is in a certain state
uint8_t ovenIsInCookingPause(OVEN_INSTANCEDATA_T *instanceVar);
uint8_t ovenIsInCooking(OVEN_INSTANCEDATA_T *instanceVar);
uint8_t ovenIsInCompleted(OVEN_INSTANCEDATA_T *instanceVar);
uint8_t ovenIsInSuper(OVEN_INSTANCEDATA_T *instanceVar);
uint8_t ovenIsInIdle(OVEN_INSTANCEDATA_T *instanceVar);


/* Macros to test if the machine is in a certain state. */
#define OVEN_IS_IN_COOKINGPAUSE(instance)((((&instance)->stateVarSuper==CookingPause)&&((&instance)->stateVar==Super)) ? (1U) : (0U))
#define OVEN_IS_IN_COOKING(instance)((((&instance)->stateVarSuper==Cooking)&&((&instance)->stateVar==Super)) ? (1U) : (0U))
#define OVEN_IS_IN_COMPLETED(instance)((((&instance)->stateVarSuper==Completed)&&((&instance)->stateVar==Super)) ? (1U) : (0U))
#define OVEN_IS_IN_SUPER(instance)((((&instance)->stateVar==Super)) ? (1U) : (0U))
#define OVEN_IS_IN_IDLE(instance)((((&instance)->stateVarSuper==Idle)&&((&instance)->stateVar==Super)) ? (1U) : (0U))


/* Helper returning the innermost active state.*/
OVEN_STATES_T ovenGetInnermostActiveState(OVEN_INSTANCEDATA_T *instanceVar);

#endif
