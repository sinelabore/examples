/* (c) Peter Mueller, 2014 - All rights reserved. Reproduction, modification,
   use or disclosure to third parties without express
   authority is forbidden. Generator running in demo mode!
   Please purchase a license if you want to use this software in projects.
 */

/* Command line options: -p Modelio -A -t OvenClass -o oven oven.xmi   */
/* This file is generated from oven.xmi - do not edit manually  */
/* Generated on: Mon Aug 31 21:14:45 CEST 2015 / version 3.6.11-b1 */



#ifndef __OVEN_ACTIVITY_H__
#define __OVEN_ACTIVITY_H__

void Activity(void);


#endif
