/*
 * (c) Peter Mueller, 2008 - 2015
 *
 * All rights reserved. Reproduction, modification,
 * use or disclosure to third parties without express
 * authority is forbidden.
 */

/* Command line options: -p Modelio -t OvenClass -o oven oven.xmi   */
/* This file is generated from oven.xmi - do not edit manually */
/* Generated on: Tue Sep 15 20:55:47 CEST 2015 / version 3.6.11-b1 */




#ifndef __OVEN_DBG_H__
#define __OVEN_DBG_H__

/* State names */
const char oven_states[]=
	"CookingPause\0Cooking\0Completed\0Super\0Idle\0__OVEN_LAST_STATE__\0";


/* State values */
const unsigned short oven_state_values[]={
	CookingPause,Cooking,Completed,Super,Idle,__OVEN_LAST_STATE__
};


const unsigned short oven_state_idx[]={
	0,13,21,31,37,42,62};

#define OVEN_EVENT_START 0


/* Event names */
const char oven_events[]=
	"evDoorOpen\0evDec\0evTimeout\0evPwr\0evDoorClosed\0evInc\0NO_MSG\0";


/* Event values */
const unsigned short oven_event_values[]={
	evDoorOpen,evDec,evTimeout,evPwr,evDoorClosed,evInc,OVEN_NO_MSG
};


/* Helper to map event enum value to an index starting from 0 */
/* Needed if the event enum value is not just 0,1,2,... */
unsigned short oven_map_event_enum(unsigned short evt){
	unsigned short i;
	for(i=0; i<6;i++){
		if(oven_event_values[i]==evt) return i;
	}
	return 6; // should never be reached
}


/* Helper to map state enum value to an index starting from 0 */
/* Needed if the event enum value is not just 0,1,2,... */
unsigned short oven_map_state_enum(unsigned short state){
	unsigned short i;
	for(i=0; i<5;i++){
		if(oven_state_values[i]==state) return i;
	}
	return 5; // should never be reached
}



const unsigned short oven_evt_idx[]={
	0,11,17,27,33,46,52
};

const char* ovenGetNameByState(unsigned short state){
	unsigned short idx = oven_map_state_enum(state);
	return oven_states+oven_state_idx[idx];
}

const char* ovenGetNameByEvent(OVEN_EVENT_T evt){
	unsigned short idx = oven_map_event_enum(evt);
	return oven_events+oven_evt_idx[idx];
}


#endif
